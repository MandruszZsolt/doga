import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kő-Papír-Olló',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: GamePage(),
    );
  }
}

class GamePage extends StatefulWidget {
  @override
  _GamePageState createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  String userChoice = '';
  String computerChoice = '';
  String result = '';
  final Random random = Random();

  void playGame(String choice) {
    userChoice = choice;
    computerChoice = ['kő', 'papír', 'olló'][random.nextInt(3)];
    evaluateResult();
  }

  void evaluateResult() {
    if (userChoice == computerChoice) {
      result = 'Döntetlen!';
    } else if ((userChoice == 'kő' && computerChoice == 'olló') ||
        (userChoice == 'papír' && computerChoice == 'kő') ||
        (userChoice == 'olló' && computerChoice == 'papír')) {
      result = 'Te nyertél!';
    } else {
      result = 'A gép nyert!';
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kő-Papír-Olló'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Válassz egyet:',
              style: TextStyle(fontSize: 24),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                GestureDetector(
                  onTap: () => playGame('kő'),
                  child: Image.asset('assets/rock.png', width: 100),
                ),
                GestureDetector(
                  onTap: () => playGame('papír'),
                  child: Image.asset('assets/paper.png', width: 100),
                ),
                GestureDetector(
                  onTap: () => playGame('olló'),
                  child: Image.asset('assets/scissors.png', width: 100),
                ),
              ],
            ),
            SizedBox(height: 20),
            Text(
              'Te választottad: $userChoice',
              style: TextStyle(fontSize: 20),
            ),
            Text(
              'A gép választása: $computerChoice',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            Text(
              result,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
