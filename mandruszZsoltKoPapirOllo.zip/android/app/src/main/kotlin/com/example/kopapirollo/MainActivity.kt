package com.example.kopapirollo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
